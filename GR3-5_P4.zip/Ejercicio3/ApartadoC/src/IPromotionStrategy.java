package Ejercicio3.ApartadoC;

public interface IPromotionStrategy {
    double applyPromotion(double basePrice);
}
