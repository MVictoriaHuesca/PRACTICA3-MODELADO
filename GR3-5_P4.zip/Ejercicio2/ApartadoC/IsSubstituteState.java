package src;
public class IsSubstituteState extends CarState {
    public IsSubstituteState(Car car) {
        super(car);
    }

    public String toString() {
        return "Substitute";
    }
}
