
public interface ICustomer<T> {
   Iterator<T> createWebRentalIterator();
}